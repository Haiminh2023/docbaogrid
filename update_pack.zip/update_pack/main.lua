-------------------------------------------------------
-- 🧩 TỰ ĐỘNG BIÊN DỊCH & ẨN MÃ NGUỒN .LUA → BYTECODE
-- (Chỉ quét thư mục gốc của plugin, không đệ quy)
-------------------------------------------------------
local function auto_protect_source()
    local plugin_dir = debug.getinfo(1, "S").source:match("@?(.*[/\\])") or "./"
    if plugin_dir:sub(-1) ~= "/" and plugin_dir:sub(-1) ~= "\\" then
        plugin_dir = plugin_dir .. "/"
    end

    local marker = plugin_dir .. ".compiled.lock"

    -- Nếu đã có marker thì không chạy lại
    local check = io.open(marker, "r")
    if check then check:close() return end

    ------------------------------------------------------------
    -- Kiểm tra file có phải bytecode không (header 0x1B 'Lua')
    ------------------------------------------------------------
    local function is_bytecode(path)
        local f = io.open(path, "rb")
        if not f then return false end
        local header = f:read(4) or ""
        f:close()
        return header:sub(1,1) == string.char(27) and header:sub(2,4) == "Lua"
    end

    ------------------------------------------------------------
    -- Biên dịch 1 file .lua sang bytecode (ghi đè an toàn)
    ------------------------------------------------------------
    local function compile_one(lua_path)
        local f = io.open(lua_path, "rb")
        if not f then
            print("[docbaogrid] ⚠️ Không mở được " .. lua_path)
            return false
        end
        local src = f:read("*a")
        f:close()

        if not src or src == "" then return false end

        local chunk, err = load(src, "@" .. lua_path)
        if not chunk then
            print("[docbaogrid] ⚠️ Lỗi load " .. lua_path .. ": " .. tostring(err))
            return false
        end

        local ok, dumped = pcall(string.dump, chunk, true)
        if not ok or not dumped then
            print("[docbaogrid] ⚠️ Lỗi dump bytecode " .. lua_path)
            return false
        end

        -- Ghi file tạm
        local tmp_path = lua_path .. ".luac.tmp"
        local out = io.open(tmp_path, "wb")
        if not out then
            print("[docbaogrid] ⚠️ Không thể tạo file tạm: " .. tmp_path)
            return false
        end
        out:write(dumped)
        out:close()

        -- Xóa file gốc rồi đổi tên file tạm
        os.remove(lua_path)
        os.rename(tmp_path, lua_path)
        return true
    end

    ------------------------------------------------------------
    -- Quét tất cả file .lua trong thư mục gốc plugin
    ------------------------------------------------------------
    local compiled_count, skipped_count = 0, 0
    local p = io.popen('ls "' .. plugin_dir .. '"')
    if not p then
        print("[docbaogrid] ⚠️ Không thể duyệt thư mục plugin")
        return
    end

    for fname in p:lines() do
        if fname:match("%.lua$") and fname ~= ".compiled.lock" then
            local full_path = plugin_dir .. fname
            if is_bytecode(full_path) then
                skipped_count = skipped_count + 1
            else
                local ok = compile_one(full_path)
                if ok then
                    compiled_count = compiled_count + 1
                    print("[docbaogrid] 🔒 Compiled: " .. fname)
                else
                    skipped_count = skipped_count + 1
                end
            end
        end
    end
    p:close()

    ------------------------------------------------------------
    -- Tạo file lock đánh dấu đã biên dịch
    ------------------------------------------------------------
    local lock = io.open(marker, "w")
    if lock then
        lock:write("compiled at " .. os.date() ..
                   "\ncompiled=" .. compiled_count ..
                   ", skipped=" .. skipped_count .. "\n")
        lock:close()
    end

    print(string.format("[docbaogrid] ✅ Hoàn tất: %d file biên dịch, %d file bỏ qua.",
        compiled_count, skipped_count))
end

-- Gọi an toàn
pcall(auto_protect_source)


-------------------------------------------------------
-- 🧩 ĐẢM BẢO UI KOReader SẴN SÀNG
-------------------------------------------------------
local function ensure_ui_ready()
    local ok, UIManager = pcall(require, "ui/uimanager")
    if not ok or not UIManager then return end
    pcall(require, "device")
    pcall(require, "gettext")
    pcall(require, "ui/widget/menu")
    pcall(require, "ui/widget/buttondialog")
    pcall(require, "ui/widget/infomessage")
    pcall(require, "ui/widget/confirmbox")
    pcall(require, "Icons")
end
pcall(ensure_ui_ready)

-------------------------------------------------------
-- ⚙️ Require các module chính
-------------------------------------------------------
local UIManager = require("ui/uimanager")
local Menu = require("menu_custom")
local InfoMessage = require("ui/widget/infomessage")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local ReaderUI = require("apps/reader/readerui")
local settings_module = require("settings")
local rss_module = require("rss")
local article_module = require("article")
local utils = require("utils")
local stories = require("stories")
local updater = require("updater")
local ButtonDialog = require("ui/widget/buttondialog")

local DocBao = WidgetContainer:new{
    name = "docbao",
    version = "11.1",
    description = "Đọc online với ReaderUI",
}

-------------------------------------------------------
-- 🌐 Hiển thị bài viết
-------------------------------------------------------
local function show_article(item)
    DocBao.last_article_item = item
    local settings = settings_module.load_settings()
    --local tmp_file = article_module.tmp_dir.."tmp_article.html"
    local tmp_file = string.format("%stmp_article_%d.html", article_module.tmp_dir, os.time())


    os.execute('mkdir -p "' .. article_module.tmp_dir .. '"')
    os.execute('mkdir -p "' .. article_module.tmp_dir .. 'tmp_images/"')

    -- xóa file cũ
    os.remove(tmp_file)

    -- ghi nội dung bài mới (HTML) ngay lập tức
    local f = io.open(tmp_file,"w")
    if f then
        f:write(article_module.get_full_article(item, settings.load_images))
        f:close()
        -- Mở ReaderUI an toàn
        pcall(function() ReaderUI:showReader(tmp_file, nil) end)
    else
        -- sử dụng UIManager đã require ở đầu
        pcall(function() UIManager:showMessage(_("Không thể ghi file tạm để hiển thị bài viết.")) end)
    end
end

-------------------------------------------------------
-- 📰 Hiển thị danh sách bài viết trong chuyên mục
-------------------------------------------------------
local function show_category(cat, site_name)
    DocBao.current_cat = cat
    DocBao.current_site = site_name

    local news = {}
    local start_index = 1
    local batch_size = 20
    local menu

    local function load_more()
        local new_items = rss_module.fetch_rss(cat.url, start_index, batch_size)
        for _, n in ipairs(new_items) do table.insert(news, n) end
        start_index = start_index + batch_size
        return #new_items
    end

    local function build_items()
        local list = {}
        for _, item in ipairs(news) do
            table.insert(list, {
                text = utils.decode_entities(item.title),
                callback = function() show_article(item) end
            })
        end
        table.insert(list, {
            text = "📥 Tải thêm tin...",
            callback = function()
                local added = load_more()
                if added > 0 and menu then
                    menu.item_table = build_items()
                    menu:updateItems()
                else
                    UIManager:show(InfoMessage:new{ text = "Không còn tin mới.", timeout = 2 })
                end
            end
        })
        return list
    end

    load_more()
    menu = Menu:new{
        title = site_name .. " - " .. cat.name,
        item_table = build_items(),
        fullscreen = true,
        topMenuButtons = {
            { text = "🔄 Làm mới chuyên mục", callback = function() DocBao.show_category(cat, site_name) end },
            { text = "⬅️ Quay lại danh mục", callback = function()
                DocBao.show_site(site_name, rss_module.load_sources()[site_name] or {})
            end },
        }
    }

    UIManager:show(menu)
end
DocBao.show_category = show_category

-------------------------------------------------------
-- 🗞️ Hiển thị danh mục của 1 trang báo
-------------------------------------------------------
local function show_site(site_name, categories)
    local items = {}
    for _, cat in ipairs(categories) do
        table.insert(items, { text = cat.name, callback = function() show_category(cat, site_name) end })
    end

    local menu = Menu:new{
        title = site_name,
        item_table = items,
        fullscreen = true,
        topMenuButtons = {
            { text = "🔄 Làm mới trang", callback = function()
                UIManager:show(InfoMessage:new{ text = "Làm mới " .. site_name, timeout = 2 })
            end },
            { text = "🏠 Quay lại danh sách báo", callback = function() DocBao.show_sites() end },
        }
    }

    UIManager:show(menu)
end
DocBao.show_site = show_site

-------------------------------------------------------
-- 🗂️ Danh sách báo
-------------------------------------------------------
local function show_sites()
    local sources = rss_module.load_sources()
    local settings = settings_module.load_settings()
    local items = {}

    for site_name, cats in pairs(sources) do
        table.insert(items, { text = site_name, callback = function() show_site(site_name, cats) end })
    end

    table.insert(items, {
        text = (settings.load_images and "✓ " or "") .. "Hiển thị ảnh",
        callback = function()
            settings.load_images = not settings.load_images
            settings_module.save_settings(settings)
            show_sites()
        end
    })

    local menu = Menu:new{
        title = "Chọn báo",
        item_table = items,
        fullscreen = true,
        topMenuButtons = {
            { text = "📰 Giới thiệu", callback = function()
                UIManager:show(InfoMessage:new{ text = "Plugin Đọc Báo Grid v9.1", timeout = 2 })
            end },
            { text = "⚙️ Cài đặt", callback = function()
                UIManager:show(InfoMessage:new{ text = "Cài đặt tổng thể.", timeout = 2 })
            end },
        }
    }

    UIManager:show(menu)
end
DocBao.show_sites = show_sites

-------------------------------------------------------
-- 🔄 Hàm kiểm tra và cập nhật plugin OTA
-------------------------------------------------------

local function check_for_update()
    local ok, info = updater.check_update(DocBao.version)
    if not ok then
        UIManager:show(InfoMessage:new{ text = info, timeout = 3 })
        return
    end

    local current_version = DocBao.version or "?"
    local new_version = info.version or "?"
    local dialog -- reference dialog để callback đóng

    -- Các nút
    local buttons = {
        {
            { text = "✅ Có", callback = function()
                UIManager:close(dialog)
                UIManager:show(InfoMessage:new{ text = "📦 Đang tải và cập nhật...", timeout = 2 })
                local success, msg = updater.apply_update(info)
                if success then
                    UIManager:show(InfoMessage:new{
                        text = string.format(
                            "✅ Cập nhật thành công lên phiên bản mới: v%s\n\n👉 Khởi động lại KOReader để áp dụng.\n\nNội dung update:\n%s",
                            info.version or "?",
                            msg or "(không có nội dung)"
                        ),
                        timeout = 6
                    })
                else
                    UIManager:show(InfoMessage:new{ text = "❌ " .. (msg or "Cập nhật lỗi."), timeout = 4 })
                end
            end }
        },
        {
            { text = "❌ Không", callback = function()
                UIManager:close(dialog)
                UIManager:show(InfoMessage:new{ text = "Bỏ qua cập nhật.", timeout = 2 })
            end }
        }
    }

    -- Tạo dialog trực tiếp
    dialog = ButtonDialog:new{
        title = string.format("Phiên bản hiện tại: v%s\nCó phiên bản mới: v%s\nBạn có muốn cập nhật?", current_version, new_version),
        buttons = buttons
    }

    UIManager:show(dialog)
end




-------------------------------------------------------
-- 📖 Menu chính của plugin
-------------------------------------------------------
local function show_main_menu()
    local items = {
        { text = "▶ Đọc báo online", callback = function() show_sites() end },
        { text = "▶ Đọc truyện online", callback = function() stories.show_stories() end },
    }
    local menu = Menu:new{
        title = "Chọn chức năng",
        item_table = items,
        topMenuButtons = {
            { text = "📰 Giới thiệu", callback = function()
                UIManager:show(InfoMessage:new{ text = "Plugin Đọc Báo Grid v" .. tostring(DocBao.version), timeout = 2 })
            end },
            { text = "⚙️ Cài đặt", callback = function()
                UIManager:show(InfoMessage:new{ text = "Cài đặt tổng thể.", timeout = 2 })
            end },
            { text = "🔄 Cập nhật", callback = function() check_for_update() end },
        }
    }


        -- Chỉ xử lý onClose cho menu cấp cao nhất để tránh KOReader thoát khi stack trống.
    menu.onClose = function()
        pcall(function()
            local FileManager = require("apps/filemanager/filemanager")

            -- Đợi 1 tick để KOReader xử lý đóng widget hiện tại trước
            UIManager:nextTick(function()
                -- Nếu không còn widget nào đang mở trên stack, mở FileManager
                local has_top = UIManager.getTopWidget and UIManager:getTopWidget() or nil
                if not has_top then
                    -- mở FileManager để giữ KOReader không thoát
                    if FileManager and type(FileManager.showFiles) == "function" then
                        FileManager:showFiles()
                    end
                end
            end)
        end)
    end

    UIManager:show(menu)
end

-------------------------------------------------------
-- 🧾 Kiểm tra License
-------------------------------------------------------
local function verify_plugin()
    local now = tonumber(os.date("%Y%m%d"))
    local expiry = 20251225
    if now > expiry then
        UIManager:show(InfoMessage:new{
            text = "⏰ Plugin đã hết hạn!\nLiên hệ: Haiphuong0430@gmail.com",
            timeout = 6,
        })
        return false
    end
    local now_time = os.time()
    local expiry_date = os.time({
        year = math.floor(expiry / 10000),
        month = math.floor((expiry % 10000) / 100),
        day = expiry % 100
    })
    local days_left = math.floor((expiry_date - now_time) / (24 * 3600))
    if days_left <= 10 then
        UIManager:show(InfoMessage:new{
            text = string.format("⚠️ Plugin sẽ hết hạn sau %d ngày!\nLiên hệ: Haiphuong0430@gmail.com", days_left),
            timeout = 5,
        })
    end
    return true
end
-------------------------------------------------------
-------------------------------------------------------
-- 🧩 Khởi tạo plugin & thêm nút "⬅️ Quay lại DocBao"
-------------------------------------------------------
function DocBao:init()
    if not self.ui then return end

    -- Đăng ký plugin vào menu chính KOReader
    if self.ui.menu then
        self.ui.menu:registerToMainMenu(self)
    end

    -------------------------------------------------------
    -- Nếu đang trong ReaderUI → thêm nút "⬅️ Quay lại DocBao"
    if self.ui.name == "ReaderUI" and self.ui.menu then
        self.ui.menu:registerToMainMenu({
            addToMainMenu = function(_, menu_items)
                menu_items.back_to_docbao = {
                    text = "⬅️ Quay lại Đọc online",
                    sorting_hint = "main", 
                    callback = function()
                        pcall(function()
                            local ReaderUI = require("apps/reader/readerui")
                            if ReaderUI.instance then
                                ReaderUI.instance:onClose()
                            end
                        end)
                    end
                }
            end
        })
    end
end

-------------------------------------------------------
-- 🧩 Đăng ký plugin vào menu chính KOReader
-------------------------------------------------------
function DocBao:addToMainMenu(menu_items)
    local icons = require("icons")
    menu_items.docbao = {
        text = "Đọc online",
        sorting_hint = "tools",
        icon = icons.FA_BOOK,
        callback = function()
            if verify_plugin() then
                show_main_menu()
            end
        end
    }
end

-------------------------------------------------------
return DocBao
-------------------------------------------------------
