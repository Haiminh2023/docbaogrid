-- version.lua
return {
    plugin_name = "docbao",
    number = "11.5",  -- Phiên bản hiện tại
    name = "Đọc online với ReaderUI",
}
