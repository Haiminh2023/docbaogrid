-- version.lua
return {
    plugin_name = "docbao",
    number = "11.4",  -- Phiên bản hiện tại
    name = "Đọc online với ReaderUI",
}
