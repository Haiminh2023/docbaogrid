-------------------------------------------------------
-- updater.lua — Cập nhật plugin OTA (Online Update)
-------------------------------------------------------
local http = require("socket.http")
local ltn12 = require("ltn12")
local json = require("dkjson")
local lfs = require("lfs")

local plugin_dir = debug.getinfo(1, "S").source:match("@?(.*[/\\])") or "./"
local zip_path = plugin_dir .. "update_tmp.zip"

-------------------------------------------------------
-- Đọc JSON từ URL
-------------------------------------------------------
local function fetch_json(url)
    local body = {}
    local _, code = http.request{ url = url, sink = ltn12.sink.table(body) }
    if code ~= 200 then return nil end
    local ok, data = pcall(function() return json.decode(table.concat(body)) end)
    if ok and type(data) == "table" then return data end
    return nil
end

-------------------------------------------------------
-- Tải file về local (ghi trực tiếp nhị phân)
-------------------------------------------------------
local function download_file(url, path)
    local f = io.open(path, "wb")
    if not f then return false end
    local ok, code = http.request{ url = url, sink = ltn12.sink.file(f) }
    return ok and code == 200
end

-------------------------------------------------------
-- Giải nén plugin.zip trực tiếp vào plugin_dir
-- và xóa file rác 0 KB sau khi giải nén
-------------------------------------------------------
local function unzip_file(zipfile, dest)
    local cmd = string.format('unzip -o -j "%s" -d "%s"', zipfile, dest)
    os.execute(cmd)

    -- xóa các file 0 KB rác trong dest
    for file in lfs.dir(dest) do
        local full = dest .. file
        local attr = lfs.attributes(full)
        if attr and attr.mode == "file" and attr.size == 0 then
            os.remove(full)
        end
    end
end

-------------------------------------------------------
-- Kiểm tra phiên bản hiện tại
-------------------------------------------------------
local function get_local_version()
    local main_path = plugin_dir .. "main.lua"
    local f = io.open(main_path, "r")
    if not f then return "0" end
    local content = f:read("*a")
    f:close()
    return content:match('version%s*=%s*["\']([%d%.]+)["\']') or "0"
end

local function version_to_number(ver)
    local t = {}
    for n in ver:gmatch("%d+") do table.insert(t, tonumber(n)) end
    return t
end

local function is_version_newer(v1, v2)
    local t1, t2 = version_to_number(v1), version_to_number(v2)
    for i = 1, math.max(#t1, #t2) do
        local n1, n2 = t1[i] or 0, t2[i] or 0
        if n1 > n2 then return true end
        if n1 < n2 then return false end
    end
    return false
end

local function check_update(_)
    local current_version = get_local_version()
    local info = fetch_json("https://raw.githubusercontent.com/Haiminh2023/docbaogrid/main/version.json")
    if not info or not info.version then
        return false, "Không tải được thông tin cập nhật."
    end
    if is_version_newer(info.version, current_version) then
        return true, info
    end
    return false, string.format("Đang ở phiên bản mới nhất (v%s).", current_version)
end

-------------------------------------------------------
-- Tải và cài đặt bản cập nhật
-------------------------------------------------------
local function apply_update(info)
    local ok = download_file(info.url, zip_path)
    if not ok then return false, "Không tải được gói cập nhật." end

    unzip_file(zip_path, plugin_dir)
    os.remove(zip_path)  -- xóa file ZIP tạm
    return true, info.changelog or "Đã cập nhật plugin."
end

return {
    check_update = check_update,
    apply_update = apply_update
}
